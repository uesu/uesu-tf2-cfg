"Resource/UI/HudHealthAccount.res"
{
	"CHealthAccountPanel"
	{
		"fieldName"		"CHealthAccountPanel"
		"delta_item_x"		"0"
		"delta_item_start_y"	"0"
		"delta_item_end_y"	"0"
		"PositiveColor"		"HealthPickupColor"
		"NegativeColor"		"255 0 0 255"
		"delta_lifetime"	"1.5"
		"delta_item_font"	"roboto30"
	}
}